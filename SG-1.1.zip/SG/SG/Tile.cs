﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SG
{
    public class Tile

    {

        public string name { get; set; }

        public string ImageCharacter { get; set; }

        public ConsoleColor Color { get; set; }

        public int X { get; set; }

        public int Y { get; set; }

        public Tile() { }

        public Tile(int x, int y)

            : base()

        {

            this.X = x;

            this.Y = y;

            ImageCharacter = Constants.TileImage;

            Color = Constants.TileColor;

        }

    }



    public class Wall : Tile

    {

        public Wall(int x, int y)

            : base(x, y)

        {

            ImageCharacter = Constants.WallImage;

            this.Color = Constants.WallColor;

        }
        public Wall(Point p)
        {

            ImageCharacter = Constants.WallImage;

            this.Color = Constants.WallColor;
            X = p.X;
            Y = p.Y;

        }

    }

    public class Sword : Tile

    {

        public Sword(Point p)

        {

            ImageCharacter = Constants.SwordImage;

            this.Color = Constants.SwordColor;

            X = p.X;

            Y = p.Y;

        }

    }




    //creature
    public class Creature : Tile

    {

        public int Hits { get; set; }

        public void Die()

        {

            Hits = 0;

        }

    }

    public class Player : Creature

    {

        public Player(Point p)

        {

            ImageCharacter = Constants.PlayerImage;

            Color = Constants.PlayerColor;

            Inventory = new List<Tile>();

            X = p.X;

            Y = p.Y;

            Hits = Constants.StartingHitPoints;

        }

        public List<Tile> Inventory { get; set; }

    }

    public class Monster : Creature

    {

        public Monster(Point p)

        {

            ImageCharacter = Constants.MonsterImage;

            Color = Constants.MonsterColor;

            X = p.X;

            Y = p.Y;

            Hits = Constants.StartingHitPoints;

        }

    }
}
