﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SG
{
    class Dungeon

    {

        Random r;

        public Player player;

        List<Monster> monsters;

        List<Sword> swords;

        List<Wall> walls;

        public Tile[,] Tiles;

        private int xMax;

        private int yMax;



        public enum Direction

        {

            North,

            South,

            East,

            West

        }



        public bool IsGameActive

        {

            get

            {

                return (player.Hits > 0 && monsters.Any(m => m.Hits > 0));

            }

        }



        public Dungeon(int xMax, int yMax)

        {

            monsters = new List<Monster>();

            walls = new List<Wall>();

            swords = new List<Sword>();

            this.xMax = xMax;

            this.yMax = yMax;

            Tiles = new Tile[xMax, yMax];

            BuildRandomDungeon();

            SetDungeonTiles();

        }



        public string ExecuteCommand(ConsoleKeyInfo command)

        {

            string commandResult = ProcessCommand(command);

            ProcessMonsters();

            SetDungeonTiles();

            return commandResult;

        }



        private void ProcessMonsters()

        {

            if (monsters != null && monsters.Count > 0)

            {

                monsters.Where(m => m.Hits >= 0).ToList().ForEach(m =>

                {
                    
                    MoveMonsterToPlayer(m);

                });

            }

        }



        private void MoveMonsterToPlayer(Monster monster)

        {

            if (player.X != monster.X)

            {

                if (player.X > monster.X)

                {

                    monster.X++;

                }

                else

                {

                    monster.X--;

                }

            }

            else if (player.Y != monster.Y)

            {

                if (player.Y > monster.Y)

                {

                    monster.Y++;

                }

                else

                {

                    monster.Y--;

                }

            }

            else

            {

                ResolveCombat(monster);

            }

        }



        private void BuildRandomDungeon()

        {

            r = new Random();

            SetAllDungeonSquaresToTiles();

            for (int i = 0; i < xMax; i++)

            {

                Wall top = new Wall(i, 0);

                walls.Add(top);

                Wall bottom = new Wall(i, yMax - 1);

                walls.Add(bottom);

            }

            for (int i = 0; i < yMax; i++)

            {

                Wall left = new Wall(0, i);

                walls.Add(left);

                Wall right = new Wall(xMax - 1, i);

                walls.Add(right);

            }
            for (int i = 0; i < Constants.NumberOfInWall; i++)

            {

                Wall s = new Wall(GetValidRandomPoint());

                walls.Add(s);

            }

            for (int i = 0; i < Constants.NumberOfSwords; i++)

            {

                Sword s = new Sword(GetValidRandomPoint());

                swords.Add(s);

            }

            for (int i = 0; i < Constants.NumberOfMonsters; i++)

            {

                Monster m = new Monster(GetValidRandomPoint());

                monsters.Add(m);

            }

            player = new Player(GetValidRandomPoint());

        }



        private void ResolveCombat(Monster monster)

        {

            if (player.Inventory.Any())

            {

                monster.Die();

            }

            else

            {

                player.Die();

            }

        }

        private Point GetValidRandomPoint()

        {

            Point p = new Point(r.Next(1, xMax - 1), r.Next(1, yMax - 1));

            while (Tiles[p.X, p.Y].ImageCharacter != Constants.TileImage)

            {

                p = new Point(r.Next(1, xMax - 1), r.Next(1, yMax - 1));

            }

            return p;

        }



        public string ProcessCommand(ConsoleKeyInfo command)

        {



            string output = string.Empty;

            switch (command.Key)

            {

                case ConsoleKey.UpArrow:

                case ConsoleKey.DownArrow:

                case ConsoleKey.RightArrow:

                case ConsoleKey.LeftArrow:

                    output = GetNewLocation(command, new Point(player.X, player.Y));

                    break;

                case ConsoleKey.F1:

                    output = Constants.NoHelpText;

                    break;

            }



            return output;

        }



        private string GetNewLocation(ConsoleKeyInfo command, Point move)

        {

            switch (command.Key)

            {

                case ConsoleKey.UpArrow:

                    move.Y -= 1;

                    break;

                case ConsoleKey.DownArrow:

                    move.Y += 1;

                    break;

                case ConsoleKey.RightArrow:

                    move.X += 1;

                    break;

                case ConsoleKey.LeftArrow:

                    move.X -= 1;

                    break;

            }

            if (Tiles[move.X, move.Y] is Wall && player.Inventory.Count == 0)

            {

                return Constants.InvalidMoveText;

            }
            if (!IsInvalidValidMove(move.X, move.Y))

            {

                player.X = move.X;

                player.Y = move.Y;

                if (Tiles[move.X, move.Y] is Sword && player.Inventory.Count == 0)

                {

                    Sword sword = (Sword)Tiles[move.X, move.Y];

                    player.Inventory.Add(sword);

                    swords.Remove(sword);

                }

                return Constants.OKCommandText;

            }

            else

                return Constants.InvalidMoveText;

        }



        public bool IsInvalidValidMove(int x, int y)

        {

            return (x == 0 || x == Constants.DungeonWidth - 1 || y == Constants.DungeonHeight - 1 || y == 0);

        }

        public void SetDungeonTiles()

        {

            //Draw the empty dungeon

            SetAllDungeonSquaresToTiles();

            SetAllDungeonObjectsToTiles();

        }

        private void SetAllDungeonObjectsToTiles()

        {

            //Draw each of the parts of the dungeon

            walls.ForEach(w => Tiles[w.X, w.Y] = w);

            swords.ForEach(s => Tiles[s.X, s.Y] = s);

            monsters.ForEach(m => Tiles[m.X, m.Y] = m);

            Tiles[player.X, player.Y] = player;

        }

        private void SetAllDungeonSquaresToTiles()

        {

            for (int i = 0; i < yMax; i++)

            {

                for (int j = 0; j < xMax; j++)

                {

                    Tiles[j, i] = new Tile(i, j);

                }

            }

        }

        public void DrawToConsole()

        {

            Console.Clear();

            for (int i = 0; i < yMax; i++)

            {

                for (int j = 0; j < xMax; j++)

                {

                    Console.ForegroundColor = Tiles[j, i].Color;

                    Console.Write(Tiles[j, i].ImageCharacter);

                }

                Console.WriteLine();

            }

        }

    }
}

